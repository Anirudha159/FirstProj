0. {Product} - product (clion, idea, etc.)
{InstallDir} - the path to the installed product (CLion, IDEA, and so on)

1. Copy JetbrainsCrack.jar to $ {InstallDir} / bin

2. Edit the file "$ {Product} .vmoptions" (or "$ {Product} $ {64} .vmoptions") in the folder {InstallDir} / bin:

2.1 Add at the end of the file (from a new line): -javaagent: {InstallDir} /bin/JetbrainsCrack.jar

3. Run the product.

4. Enter any value in the key field.



-------------------------------------
1.	Move .jar file to the installation directory.

2.	Open bin/<IDE name>.exe.vmoptions file, for example for me it's at

3.	C:\Program Files\JetBrains\PyCharm 2018.1\bin\pycharm.exe.vmoptions
	WARNING: if you installed IDE only for your current user, then you have to edit .vmoptions files that are placed in %USERPOFILE% folder!
	For example,
	C:\Users\YOURUSERNAME\.PhpStorm2017.3\config

4.	At the end of this file paste this and save (replace path to .jar file with your path, make sure it doesn't have quotes):
-javaagent:C:\Program Files\JetBrains\PyCharm 2018.1\bin\JetbrainsCrack.jar

5.	Do the same for bin/<IDE name>64.exe.vmoptions file, paste the same into this file as well. Again, if you have IDE installed for your current user, edit file inside %USERPOFILE%\<IDE folder>\config











































WWW.DOWNLOADLY.IR